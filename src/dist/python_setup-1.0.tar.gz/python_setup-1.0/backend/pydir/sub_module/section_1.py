def secyion_a():
    print("テスト1")

secyion_a()
